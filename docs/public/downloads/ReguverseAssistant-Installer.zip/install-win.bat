@echo off
chcp 65001 >nul 2>&1
setlocal EnableExtensions

title Reguverse Assistant - Word Add-in Installer

echo.
echo ============================================
echo   Reguverse Assistant - Word Add-in Installer
echo ============================================
echo.

set "SCRIPT_DIR=%~dp0"
set "MANIFEST=manifest.vps.xml"
set "MANIFEST_SRC=%SCRIPT_DIR%%MANIFEST%"
set "INSTALL_DIR=%LOCALAPPDATA%\ReguverseAddins"
set "MANIFEST_PATH=%INSTALL_DIR%\%MANIFEST%"
set "REG_KEY=HKCU\SOFTWARE\Microsoft\Office\16.0\WEF\Developer"
:: Add-in ID from manifest.vps.xml <Id> element
set "ADDIN_ID=84cda2d3-23bb-4fea-b68f-42c103bb995c"

if not exist "%MANIFEST_SRC%" (
    echo [ERROR] Cannot find %MANIFEST% next to this installer.
    echo         Folder: %SCRIPT_DIR%
    echo.
    pause
    exit /b 1
)

:: Step 1: Copy manifest to a permanent location
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
copy /Y "%MANIFEST_SRC%" "%MANIFEST_PATH%" >nul
echo [1/3] Manifest copied to:
echo       %MANIFEST_PATH%
echo.

:: Step 2: Create the Developer key
echo [2/3] Creating registry key...
reg add "%REG_KEY%" /f
if errorlevel 1 (
    echo.
    echo [ERROR] Failed to create registry key: %REG_KEY%
    echo         Try: right-click install-win.bat ^> Run as administrator
    echo.
    pause
    exit /b 1
)

:: Step 3: Register add-in
:: Format matches office-addin-dev-settings register:
::   Value name = Add-in ID (from manifest <Id>)
::   Value data = full path to manifest file
echo [3/3] Registering add-in (ID: %ADDIN_ID%)...
reg add "%REG_KEY%" /v "%ADDIN_ID%" /t REG_SZ /d "%MANIFEST_PATH%" /f
if errorlevel 1 (
    echo.
    echo [ERROR] Failed to write registry value.
    echo.
    pause
    exit /b 1
)

:: Verify
echo.
echo Verifying...
reg query "%REG_KEY%" /v "%ADDIN_ID%"
if errorlevel 1 (
    echo.
    echo [WARNING] Verification failed.
    echo.
    pause
    exit /b 1
)

echo.
echo ============================================
echo   [OK] Installation complete!
echo ============================================
echo.
echo Next steps:
echo   1. Close Word completely (File ^> Exit, or check Task Manager).
echo   2. Open Word again.
echo   3. Look for "Reguverse" group on the Home tab ribbon.
echo   4. Click "Reguverse Assistant" to open the panel.
echo.
echo If the add-in does NOT appear on the ribbon:
echo   - Make sure Word was fully closed (check Task Manager for WINWORD.EXE).
echo   - Open regedit and verify:
echo     Key:   %REG_KEY%
echo     Value: %ADDIN_ID%  (REG_SZ)
echo     Data:  %MANIFEST_PATH%
echo.
pause
