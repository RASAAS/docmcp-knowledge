Reguverse Assistant - Production (International) (国际版)
=========================================
Frontend: https://app.team-ra.org
Backend:  https://llm.team-ra.org

== Installation ==

  Windows:
    Option 1: Double-click install.bat
    Option 2: Right-click install.ps1 > "Run with PowerShell"

  macOS:
    Open Terminal, navigate to this folder, run:
      bash install.sh

  IMPORTANT: After installation, close ALL Word windows
  and re-open Word for the add-in to appear.

== Activating the Add-in ==

  Windows:
    1. Open Word
    2. Home tab > Add-ins (or Insert > My Add-ins)
    3. Click "SHARED FOLDER" tab at the top
    4. Select "Reguverse Assistant" and click "Add"

  macOS:
    1. Open Word
    2. Insert > My Add-ins
    3. Select "Reguverse Assistant"

== Uninstall ==

  Windows: Double-click uninstall.bat (or run uninstall.ps1)
  macOS:   Run: bash uninstall.sh

== Switching Versions ==

  To switch between CN/International versions:
  1. Run uninstall for the current version
  2. Close ALL Word windows
  3. Run install for the new version
  4. Re-open Word

== Troubleshooting ==

  "SHARED FOLDER" tab is empty or add-in not showing:
  1. Close ALL Office applications (Word, Excel, etc.)
  2. Re-run the installer
  3. Open Word and check again

  Still not working:
  1. Open File Explorer, go to:
     %LOCALAPPDATA%\Microsoft\Office\16.0\Wef\
  2. Delete the "webextensions" folder if it exists
  3. Re-run the installer and restart Word
