Reguverse Assistant - Word Add-in
=================================

This package installs the Reguverse Assistant add-in for Microsoft Word.
此安装包用于安装 Reguverse Assistant Word 加载项。

INSTALLATION / 安装
-------------------

macOS:
  1. Make sure Microsoft Word is installed / 确认已安装 Microsoft Word
  2. Double-click "install-mac.command" / 双击 "install-mac.command"
  3. Restart Word / 重启 Word
  4. The add-in appears as "Reguverse" on the Home tab ribbon
     加载项将出现在 Home 选项卡的 Ribbon 上，名为 "Reguverse"

Windows:
  1. Make sure Microsoft Word is installed / 确认已安装 Microsoft Word
  2. Double-click "install-win.bat" (no admin required)
     双击 "install-win.bat"（无需管理员权限）
  3. Close Word completely, then reopen it
     完全关闭 Word（可在任务管理器中确认无 WINWORD.EXE 进程），然后重新打开
  4. The add-in appears as "Reguverse" on the Home tab ribbon
     加载项将出现在 Home 选项卡的 Ribbon 上，名为 "Reguverse"

UNINSTALL / 卸载
-----------------

macOS:
  Open Finder, press Cmd+Shift+G, go to:
  打开 Finder，按 Cmd+Shift+G，前往：
    ~/Library/Containers/com.microsoft.Word/Data/Documents/wef/
  Delete "manifest.vps.xml", then restart Word.
  删除 "manifest.vps.xml"，然后重启 Word。

Windows:
  Open Command Prompt and run / 打开命令提示符并执行：
    reg delete "HKCU\SOFTWARE\Microsoft\Office\16.0\WEF\Developer" /v "84cda2d3-23bb-4fea-b68f-42c103bb995c" /f
  Delete the folder / 删除文件夹：
    %LOCALAPPDATA%\ReguverseAddins
  Then restart Word. / 然后重启 Word。

SUPPORT / 支持
--------------
Contact your administrator for help.
如需帮助请联系管理员。
