#!/bin/bash
# ============================================================
#  Reguverse Assistant  --  macOS One-Click Installer
# ============================================================
#  Double-click this file to install the Word add-in.
#  It copies the manifest XML into Word's sideload directory.
# ============================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
MANIFEST="manifest.vps.xml"
MANIFEST_PATH="$SCRIPT_DIR/$MANIFEST"

WEF_DIR="$HOME/Library/Containers/com.microsoft.Word/Data/Documents/wef"

echo ""
echo "============================================"
echo "  Reguverse Assistant - Word Add-in Installer"
echo "============================================"
echo ""

# Check manifest exists next to this script
if [ ! -f "$MANIFEST_PATH" ]; then
    echo "[ERROR] Cannot find $MANIFEST in the same folder as this installer."
    echo "        Please make sure '$MANIFEST' is in:"
    echo "        $SCRIPT_DIR"
    echo ""
    echo "Press Enter to close..."
    read -r
    exit 1
fi

# Check Word is installed
if [ ! -d "$HOME/Library/Containers/com.microsoft.Word" ]; then
    echo "[ERROR] Microsoft Word does not appear to be installed."
    echo "        Please install Word from the Mac App Store or Office.com first."
    echo ""
    echo "Press Enter to close..."
    read -r
    exit 1
fi

# Create wef directory if needed
if [ ! -d "$WEF_DIR" ]; then
    echo "Creating add-in directory..."
    mkdir -p "$WEF_DIR"
fi

# Copy manifest
echo "Installing Reguverse Assistant add-in..."
cp "$MANIFEST_PATH" "$WEF_DIR/$MANIFEST"

echo ""
echo "[OK] Installation complete!"
echo ""
echo "Next steps:"
echo "  1. Quit Word completely (Cmd+Q)"
echo "  2. Reopen Word"
echo "  3. Go to Home tab -> look for 'Reguverse' group on the ribbon"
echo "  4. Click 'Reguverse Assistant' to open the panel"
echo ""
echo "To uninstall, delete this file:"
echo "  $WEF_DIR/$MANIFEST"
echo ""
echo "Press Enter to close..."
read -r
