# Reguverse Assistant Installer (Production (International))
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Write-Host "============================================" -ForegroundColor Cyan
Write-Host " Reguverse Assistant - Production (International)" -ForegroundColor Cyan
Write-Host " 国际版" -ForegroundColor Cyan
Write-Host " (app.team-ra.org)" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ManifestSrc = Join-Path $ScriptDir "manifest.xml"
$CatalogDir = Join-Path $env:LOCALAPPDATA "Microsoft\Office\16.0\Wef\Reguverse"
$CatalogGuid = "A1B2C3D4-E5F6-7890-ABCD-100000000004"
$RegPath = "HKCU:\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\reguverse"
$CachePath = Join-Path $env:LOCALAPPDATA "Microsoft\Office\16.0\Wef\webextensions"

Write-Host "[1/4] Clearing Office Add-in cache..." -ForegroundColor Yellow
if (Test-Path $CachePath) {
    Remove-Item -Path $CachePath -Recurse -Force -ErrorAction SilentlyContinue
}

Write-Host "[2/4] Creating catalog directory..." -ForegroundColor Yellow
if (-not (Test-Path $CatalogDir)) { New-Item -ItemType Directory -Path $CatalogDir -Force | Out-Null }

Write-Host "[3/4] Copying manifest file..." -ForegroundColor Yellow
Copy-Item -Path $ManifestSrc -Destination (Join-Path $CatalogDir "manifest.xml") -Force

Write-Host "[4/4] Registering trusted add-in catalog..." -ForegroundColor Yellow
if (-not (Test-Path $RegPath)) { New-Item -Path $RegPath -Force | Out-Null }
Set-ItemProperty -Path $RegPath -Name "Id" -Value $CatalogGuid
Set-ItemProperty -Path $RegPath -Name "Url" -Value $CatalogDir
Set-ItemProperty -Path $RegPath -Name "Flags" -Value 1

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host " Installation complete!" -ForegroundColor Green
Write-Host ""
Write-Host " IMPORTANT: Close ALL Word windows first," -ForegroundColor White
Write-Host " then re-open Word." -ForegroundColor White
Write-Host ""
Write-Host " To activate:" -ForegroundColor White
Write-Host " 1. Open Word" -ForegroundColor White
Write-Host " 2. Home > Add-ins (or Insert > My Add-ins)" -ForegroundColor White
Write-Host " 3. Click 'SHARED FOLDER' tab" -ForegroundColor White
Write-Host " 4. Select 'Reguverse Assistant'" -ForegroundColor White
Write-Host " 5. Click 'Add'" -ForegroundColor White
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "Press Enter to exit..." -ForegroundColor Gray
Read-Host
