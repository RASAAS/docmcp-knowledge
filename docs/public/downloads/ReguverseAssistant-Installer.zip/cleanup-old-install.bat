@echo off
chcp 65001 >nul
title Reguverse Assistant - Clean Up ALL Old Installations
echo ============================================
echo  Clean up ALL old Reguverse installations
echo  Run this FIRST if switching from an older
echo  installer version.
echo ============================================
echo.

echo [1/8] Removing old Developer sideload registry...
reg delete "HKCU\SOFTWARE\Microsoft\Office\16.0\WEF\Developer" /f >nul 2>&1
reg delete "HKCU\SOFTWARE\Microsoft\Office\16.0\Wef\Developer" /f >nul 2>&1

echo [2/8] Removing old ReguverseAddins directory...
if exist "%LOCALAPPDATA%\ReguverseAddins" (
    rd /s /q "%LOCALAPPDATA%\ReguverseAddins" >nul 2>&1
    echo       Removed ReguverseAddins
)

echo [3/8] Removing old Desktop folder...
if exist "%USERPROFILE%\Desktop\ReguverseAssistant" (
    rd /s /q "%USERPROFILE%\Desktop\ReguverseAssistant" >nul 2>&1
    echo       Removed Desktop\ReguverseAssistant
)

echo [4/8] Removing old non-GUID registry entries...
for %%K in (reguverse reguverse-cn reguverse-test reguverse-cn-test) do (
    reg delete "HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%%K" /f >nul 2>&1
)

echo [5/8] Removing GUID-format registry entries...
for %%G in (
    {B1C2D3E4-F5A6-4890-ABCD-100000000001}
    {B1C2D3E4-F5A6-4890-ABCD-200000000002}
    {B1C2D3E4-F5A6-4890-ABCD-300000000003}
    {B1C2D3E4-F5A6-4890-ABCD-400000000004}
) do (
    reg delete "HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%%G" /f >nul 2>&1
)

echo [6/8] Removing network shares...
for %%S in (Reguverse ReguverseCN ReguverseTest ReguverseCNTest) do (
    net share %%S /delete >nul 2>&1
)

echo [7/8] Removing catalog directories...
for %%D in (Reguverse ReguverseCN ReguverseTest ReguverseCNTest CustomAddin) do (
    if exist "%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\%%D" (
        rd /s /q "%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\%%D" >nul 2>&1
        echo       Removed %%D
    )
)

echo [8/8] Clearing Office Add-in cache...
if exist "%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\webextensions" (
    rd /s /q "%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\webextensions" >nul 2>&1
    echo       Cleared webextensions cache
)
for /d %%F in ("%LOCALAPPDATA%\Packages\Microsoft.Win32WebViewHost_*") do (
    if exist "%%F\AC" (
        rd /s /q "%%F\AC" >nul 2>&1
        echo       Cleared WebView2 cache in %%F
    )
)

echo.
echo ============================================
echo  Cleanup complete!
echo.
echo  Now:
echo  1. Close ALL Word windows
echo  2. Run the install.bat from the version
echo     you want to use
echo  3. Re-open Word
echo ============================================
echo.
pause
