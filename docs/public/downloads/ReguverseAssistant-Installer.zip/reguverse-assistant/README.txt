Reguverse Assistant - Reguverse Assistant
=========================================

== Installation ==

  Windows:
    Option 1: Double-click install.bat (recommended)
    Option 2: Right-click install.ps1 > "Run with PowerShell"

  macOS:
    Open Terminal, navigate to this folder, run:
      bash install.sh

  IMPORTANT: After installation, close ALL Word windows
  and re-open Word for the add-in to appear.

== Finding the Add-in ==

  Windows:
    1. Open Word
    2. Home tab > Add-ins
    3. "Reguverse Assistant" should appear under MY ADD-INS
    4. If not visible, click "More Add-ins" and check MY ADD-INS

  macOS:
    1. Open Word
    2. Insert > My Add-ins
    3. Select "Reguverse Assistant"

== Uninstall ==

  Windows: Double-click uninstall.bat (or run uninstall.ps1)
  macOS:   Run: bash uninstall.sh

== Switching Versions ==

  To switch between CN/International versions:
  1. Run cleanup-old-install.bat (in parent folder) first
  2. Close ALL Word windows
  3. Run install.bat from the new version folder
  4. Re-open Word

== Troubleshooting ==

  Add-in not showing after install:
  1. Close ALL Office applications (Word, Excel, etc.)
  2. Run cleanup-old-install.bat (in parent folder)
  3. Re-run install.bat
  4. Open Word > Home > Add-ins > check MY ADD-INS

  Cache issues:
  1. Close ALL Office applications
  2. Open File Explorer, go to:
     %LOCALAPPDATA%\Microsoft\Office\16.0\Wef\
  3. Delete "webextensions" folder if it exists
  4. Re-run installer and restart Word
