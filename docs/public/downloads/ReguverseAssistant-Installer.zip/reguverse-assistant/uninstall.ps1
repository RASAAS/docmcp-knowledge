$ErrorActionPreference = "SilentlyContinue"
Write-Host "============================================"
Write-Host "  Uninstalling: Reguverse Assistant"
Write-Host "============================================"
Write-Host ""

$AddinId = "84cda2d3-23bb-4fea-b68f-42c103bb995c"
$ManifestDir = "$env:LOCALAPPDATA\ReguverseAssistant\reguverse-assistant"
$RegKey = "HKCU:\SOFTWARE\Microsoft\Office\16.0\Wef\Developer"

Write-Host "[1/4] Removing add-in registration..."
if (Test-Path $RegKey) {
    Remove-ItemProperty -Path $RegKey -Name $AddinId -ErrorAction SilentlyContinue
}

Write-Host "[2/4] Removing manifest directory..."
if (Test-Path $ManifestDir) { Remove-Item -Recurse -Force $ManifestDir }

Write-Host "[3/4] Clearing Office Add-in cache..."
$cacheDir = "$env:LOCALAPPDATA\Microsoft\Office\16.0\Wef\webextensions"
if (Test-Path $cacheDir) { Remove-Item -Recurse -Force $cacheDir }
Get-ChildItem "$env:LOCALAPPDATA\Packages\Microsoft.Win32WebViewHost_*" -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    $ac = Join-Path $_.FullName "AC"
    if (Test-Path $ac) { Remove-Item -Recurse -Force $ac }
}

Write-Host "[4/4] Done!"
Write-Host ""
Write-Host "============================================"
Write-Host "  Uninstall complete."
Write-Host "  Please close ALL Word windows and re-open."
Write-Host "============================================"
Write-Host ""
Read-Host "Press Enter to exit"
