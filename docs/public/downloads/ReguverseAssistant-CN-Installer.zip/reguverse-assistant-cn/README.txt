Reguverse Assistant - CN (国内版)
=========================================

== Installation ==

  Windows:
    Option 1: Double-click install.bat (recommended)
    Option 2: Right-click install.ps1 > "Run with PowerShell"

  macOS:
    Open Terminal, navigate to this folder, run:
      bash install.sh

  IMPORTANT: After installation, close ALL Word windows
  and re-open Word for the add-in to appear.

== Activating the Add-in ==

  Windows:
    1. Open Word
    2. Home tab > Add-ins (or Insert > My Add-ins)
    3. Click "SHARED FOLDER" tab at the top
    4. Select "Reguverse Assistant CN" and click "Add"

  macOS:
    1. Open Word
    2. Insert > My Add-ins
    3. Select "Reguverse Assistant CN"

== Uninstall ==

  Windows: Double-click uninstall.bat (or run uninstall.ps1)
  macOS:   Run: bash uninstall.sh

== Switching Versions ==

  To switch between CN/International versions:
  1. Run cleanup-old-install.bat (in parent folder) first
  2. Close ALL Word windows
  3. Run install.bat from the new version folder
  4. Re-open Word

== Troubleshooting ==

  "SHARED FOLDER" tab is empty or add-in not showing:

  Method 1 - Reinstall:
    1. Close ALL Office applications
    2. Run cleanup-old-install.bat (in parent folder)
    3. Re-run install.bat
    4. Open Word and check

  Method 2 - Manual Trust Center setup:
    1. Open Word > File > Options > Trust Center
    2. Click "Trust Center Settings"
    3. Click "Trusted Add-in Catalogs"
    4. In the Catalog Url box, enter:
       %LOCALAPPDATA%\Microsoft\Office\16.0\Wef\ReguverseCN
    5. Click "Add catalog"
    6. Check "Show in Menu" for the new entry
    7. Click OK > OK > restart Word
    8. Home > Add-ins > SHARED FOLDER > Reguverse Assistant CN

  Cache issues:
    1. Close ALL Office applications
    2. Open File Explorer, go to:
       %LOCALAPPDATA%\Microsoft\Office\16.0\Wef\
    3. Delete "webextensions" folder if it exists
    4. Re-run installer and restart Word
