@echo off
chcp 65001 >nul
title Reguverse Assistant CN - Installer
echo ============================================
echo  Installing: Reguverse Assistant CN
echo ============================================
echo.

set "MANIFEST_DIR=%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\ReguverseCN"
set "SHARE_NAME=ReguverseCN"
set "CATALOG_GUID={B1C2D3E4-F5A6-4890-ABCD-200000000002}"
set "REG_PATH=HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%CATALOG_GUID%"

echo [1/6] Clearing old sideload entries (if any)...
reg delete "HKCU\SOFTWARE\Microsoft\Office\16.0\WEF\Developer" /f >nul 2>&1
reg delete "HKCU\SOFTWARE\Microsoft\Office\16.0\Wef\Developer" /f >nul 2>&1
if exist "%LOCALAPPDATA%\ReguverseAddins" rd /s /q "%LOCALAPPDATA%\ReguverseAddins" >nul 2>&1

echo [2/6] Clearing Office Add-in cache...
if exist "%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\webextensions" (
    rd /s /q "%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\webextensions" >nul 2>&1
)

echo [3/6] Creating manifest directory...
if not exist "%MANIFEST_DIR%" mkdir "%MANIFEST_DIR%"

echo [4/6] Copying manifest file...
copy /Y "%~dp0manifest.xml" "%MANIFEST_DIR%\manifest.xml" >nul
if errorlevel 1 (
    echo [ERROR] Failed to copy manifest file.
    pause
    exit /b 1
)

echo [5/6] Sharing directory as network folder...
net share %SHARE_NAME% /delete >nul 2>&1
net share %SHARE_NAME%="%MANIFEST_DIR%" /grant:everyone,READ >nul 2>&1
if errorlevel 1 (
    echo [WARNING] Could not create network share.
    echo          Trying alternative method via Trust Center...
    echo.
    echo    Please add the catalog manually:
    echo    1. Word ^> File ^> Options ^> Trust Center ^> Trust Center Settings
    echo    2. Trusted Add-in Catalogs
    echo    3. Add: %MANIFEST_DIR%
    echo    4. Check "Show in Menu"
    echo    5. Click OK, restart Word
    echo.
    set "SHARE_PATH=%MANIFEST_DIR%"
    goto :register
)
set "SHARE_PATH=\\%COMPUTERNAME%\%SHARE_NAME%"

:register
echo [6/6] Registering trusted add-in catalog...
reg add "%REG_PATH%" /v Id /t REG_SZ /d "%CATALOG_GUID%" /f >nul 2>&1
reg add "%REG_PATH%" /v Url /t REG_SZ /d "%SHARE_PATH%" /f >nul 2>&1
reg add "%REG_PATH%" /v Flags /t REG_DWORD /d 1 /f >nul 2>&1

echo.
echo ============================================
echo  Installation complete!
echo.
echo  IMPORTANT: Close ALL Word windows first,
echo  then re-open Word.
echo.
echo  To activate the add-in:
echo  1. Open Microsoft Word
echo  2. Home ^> Add-ins (or Insert ^> My Add-ins)
echo  3. Click "SHARED FOLDER" tab
echo  4. Select "Reguverse Assistant CN"
echo  5. Click "Add"
echo.
echo  If "SHARED FOLDER" is empty, add manually:
echo  Word ^> File ^> Options ^> Trust Center ^>
echo  Trust Center Settings ^> Trusted Add-in Catalogs
echo  Add: %SHARE_PATH%
echo  Check "Show in Menu" ^> OK ^> restart Word
echo ============================================
echo.
pause
