$ErrorActionPreference = "Stop"
Write-Host "============================================"
Write-Host "  Installing: Reguverse Assistant CN"
Write-Host "============================================"
Write-Host ""

$AddinId = "84cda2d3-23bb-4fea-b68f-42c103bb995f"
$ManifestDir = "$env:LOCALAPPDATA\ReguverseAssistant\reguverse-assistant-cn"
$RegKey = "HKCU:\SOFTWARE\Microsoft\Office\16.0\Wef\Developer"
$CacheDir = "$env:LOCALAPPDATA\Microsoft\Office\16.0\Wef\webextensions"

Write-Host "[1/5] Clearing Office Add-in cache..."
if (Test-Path $CacheDir) { Remove-Item -Recurse -Force $CacheDir }
Get-ChildItem "$env:LOCALAPPDATA\Packages\Microsoft.Win32WebViewHost_*" -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    $ac = Join-Path $_.FullName "AC"
    if (Test-Path $ac) { Remove-Item -Recurse -Force $ac }
}

Write-Host "[2/5] Creating manifest directory..."
if (-not (Test-Path $ManifestDir)) { New-Item -ItemType Directory -Path $ManifestDir -Force | Out-Null }

Write-Host "[3/5] Copying manifest file..."
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Copy-Item -Force (Join-Path $scriptDir "manifest.xml") (Join-Path $ManifestDir "manifest.xml")

Write-Host "[4/5] Registering add-in in Developer settings..."
if (-not (Test-Path $RegKey)) { New-Item -Path $RegKey -Force | Out-Null }
Set-ItemProperty -Path $RegKey -Name $AddinId -Value "$ManifestDir\manifest.xml" -Type String

Write-Host "[5/5] Done!"
Write-Host ""
Write-Host "============================================"
Write-Host "  Installation complete!"
Write-Host ""
Write-Host "  Close ALL Word windows, then re-open Word."
Write-Host "  The add-in will appear in:"
Write-Host "    Home > Add-ins > MY ADD-INS"
Write-Host ""
Write-Host "  Look for: Reguverse Assistant CN"
Write-Host "============================================"
Write-Host ""
Read-Host "Press Enter to exit"
