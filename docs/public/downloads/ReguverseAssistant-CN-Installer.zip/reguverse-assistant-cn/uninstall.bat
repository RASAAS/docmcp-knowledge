@echo off
chcp 65001 >nul
title Reguverse Assistant CN - Uninstaller
echo ============================================
echo  Uninstalling: Reguverse Assistant CN
echo ============================================
echo.

set "MANIFEST_DIR=%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\ReguverseCN"
set "SHARE_NAME=ReguverseCN"
set "CATALOG_GUID={B1C2D3E4-F5A6-4890-ABCD-200000000002}"
set "REG_PATH=HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%CATALOG_GUID%"

echo [1/5] Removing network share...
net share %SHARE_NAME% /delete >nul 2>&1

echo [2/5] Removing manifest directory...
if exist "%MANIFEST_DIR%" rd /s /q "%MANIFEST_DIR%" >nul 2>&1

echo [3/5] Removing registry entry...
reg delete "%REG_PATH%" /f >nul 2>&1

echo [4/5] Removing old Developer sideload entries (if any)...
reg delete "HKCU\SOFTWARE\Microsoft\Office\16.0\WEF\Developer" /f >nul 2>&1
reg delete "HKCU\SOFTWARE\Microsoft\Office\16.0\Wef\Developer" /f >nul 2>&1
if exist "%LOCALAPPDATA%\ReguverseAddins" rd /s /q "%LOCALAPPDATA%\ReguverseAddins" >nul 2>&1

echo [5/5] Clearing Office Add-in cache...
if exist "%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\webextensions" (
    rd /s /q "%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\webextensions" >nul 2>&1
)
for /d %%F in ("%LOCALAPPDATA%\Packages\Microsoft.Win32WebViewHost_*") do (
    if exist "%%F\AC" rd /s /q "%%F\AC" >nul 2>&1
)

echo.
echo ============================================
echo  Uninstall complete.
echo  Please close ALL Word windows and re-open.
echo ============================================
echo.
pause
