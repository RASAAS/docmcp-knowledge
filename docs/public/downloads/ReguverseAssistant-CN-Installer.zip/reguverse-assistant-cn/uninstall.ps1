$ErrorActionPreference = "SilentlyContinue"
Write-Host "============================================"
Write-Host "  Uninstalling: Reguverse Assistant CN"
Write-Host "============================================"
Write-Host ""

$ManifestDir = "$env:LOCALAPPDATA\Microsoft\Office\16.0\Wef\ReguverseCN"
$ShareName = "ReguverseCN"
$CatalogGUID = "{B1C2D3E4-F5A6-4890-ABCD-200000000002}"
$RegPath = "HKCU:\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\$CatalogGUID"

Write-Host "[1/5] Removing network share..."
net share $ShareName /delete 2>$null | Out-Null

Write-Host "[2/5] Removing manifest directory..."
if (Test-Path $ManifestDir) { Remove-Item -Recurse -Force $ManifestDir }

Write-Host "[3/5] Removing registry entry..."
if (Test-Path $RegPath) { Remove-Item -Force $RegPath }

Write-Host "[4/5] Removing old Developer sideload entries..."
Remove-Item -Force -ErrorAction SilentlyContinue "HKCU:\SOFTWARE\Microsoft\Office\16.0\WEF\Developer"
Remove-Item -Force -ErrorAction SilentlyContinue "HKCU:\SOFTWARE\Microsoft\Office\16.0\Wef\Developer"
$oldDir = "$env:LOCALAPPDATA\ReguverseAddins"
if (Test-Path $oldDir) { Remove-Item -Recurse -Force $oldDir }

Write-Host "[5/5] Clearing Office Add-in cache..."
$cacheDir = "$env:LOCALAPPDATA\Microsoft\Office\16.0\Wef\webextensions"
if (Test-Path $cacheDir) { Remove-Item -Recurse -Force $cacheDir }
Get-ChildItem "$env:LOCALAPPDATA\Packages\Microsoft.Win32WebViewHost_*" -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    $ac = Join-Path $_.FullName "AC"
    if (Test-Path $ac) { Remove-Item -Recurse -Force $ac }
}

Write-Host ""
Write-Host "============================================"
Write-Host "  Uninstall complete."
Write-Host "  Please close ALL Word windows and re-open."
Write-Host "============================================"
Write-Host ""
Read-Host "Press Enter to exit"
