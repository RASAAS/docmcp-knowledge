@echo off
chcp 65001 >nul
title Reguverse Assistant Uninstaller (Reguverse Assistant (Test))
echo ============================================
echo  Uninstalling: Reguverse Assistant (Test)
echo ============================================
echo.

set "CATALOG_DIR=%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\ReguverseTest"
set "REG_PATH=HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\reguverse-test"
set "CACHE_DIR=%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\webextensions"

echo [1/5] Removing manifest and catalog directory...
if exist "%CATALOG_DIR%" rd /s /q "%CATALOG_DIR%" >nul 2>&1

echo [2/5] Removing catalog registry entry...
reg delete "%REG_PATH%" /f >nul 2>&1

echo [3/5] Removing old Developer sideload entries (if any)...
reg delete "HKCU\SOFTWARE\Microsoft\Office\16.0\WEF\Developer" /f >nul 2>&1
reg delete "HKCU\SOFTWARE\Microsoft\Office\16.0\Wef\Developer" /f >nul 2>&1
if exist "%LOCALAPPDATA%\ReguverseAddins" rd /s /q "%LOCALAPPDATA%\ReguverseAddins" >nul 2>&1

echo [4/5] Clearing Office Add-in cache...
if exist "%CACHE_DIR%" rd /s /q "%CACHE_DIR%" >nul 2>&1

echo [5/5] Clearing WebView2 cache...
for /d %%F in ("%LOCALAPPDATA%\Packages\Microsoft.Win32WebViewHost_*") do (
    if exist "%%F\AC" rd /s /q "%%F\AC" >nul 2>&1
)

echo.
echo ============================================
echo  Uninstall complete.
echo  Please close ALL Word windows and re-open.
echo ============================================
echo.
pause
