$ErrorActionPreference = "Stop"
Write-Host "============================================"
Write-Host "  Installing: Reguverse Assistant (Test)"
Write-Host "============================================"
Write-Host ""

$ManifestDir = "$env:LOCALAPPDATA\Microsoft\Office\16.0\Wef\ReguverseTest"
$ShareName = "ReguverseTest"
$CatalogGUID = "{B1C2D3E4-F5A6-4890-ABCD-300000000003}"
$RegPath = "HKCU:\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\$CatalogGUID"

Write-Host "[1/6] Clearing old sideload entries..."
Remove-Item -Force -ErrorAction SilentlyContinue "HKCU:\SOFTWARE\Microsoft\Office\16.0\WEF\Developer"
Remove-Item -Force -ErrorAction SilentlyContinue "HKCU:\SOFTWARE\Microsoft\Office\16.0\Wef\Developer"
$oldDir = "$env:LOCALAPPDATA\ReguverseAddins"
if (Test-Path $oldDir) { Remove-Item -Recurse -Force $oldDir }

Write-Host "[2/6] Clearing Office Add-in cache..."
$cacheDir = "$env:LOCALAPPDATA\Microsoft\Office\16.0\Wef\webextensions"
if (Test-Path $cacheDir) { Remove-Item -Recurse -Force $cacheDir }

Write-Host "[3/6] Creating manifest directory..."
if (-not (Test-Path $ManifestDir)) { New-Item -ItemType Directory -Path $ManifestDir -Force | Out-Null }

Write-Host "[4/6] Copying manifest file..."
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Copy-Item -Force (Join-Path $scriptDir "manifest.xml") (Join-Path $ManifestDir "manifest.xml")

Write-Host "[5/6] Sharing directory as network folder..."
$SharePath = $ManifestDir
try {
    net share $ShareName /delete 2>$null | Out-Null
    net share "$ShareName=$ManifestDir" /grant:everyone`,READ 2>$null | Out-Null
    $SharePath = "\\\\$env:COMPUTERNAME\\$ShareName"
    Write-Host "       Shared as: $SharePath"
} catch {
    Write-Host "[WARNING] Could not create network share."
    Write-Host "          Using local path as fallback."
    Write-Host "          You may need to add the catalog manually in Trust Center."
}

Write-Host "[6/6] Registering trusted add-in catalog..."
if (-not (Test-Path $RegPath)) { New-Item -Path $RegPath -Force | Out-Null }
Set-ItemProperty -Path $RegPath -Name "Id" -Value $CatalogGUID -Type String
Set-ItemProperty -Path $RegPath -Name "Url" -Value $SharePath -Type String
Set-ItemProperty -Path $RegPath -Name "Flags" -Value 1 -Type DWord

Write-Host ""
Write-Host "============================================"
Write-Host "  Installation complete!"
Write-Host ""
Write-Host "  Close ALL Word windows, then re-open."
Write-Host ""
Write-Host "  To activate: Home > Add-ins > SHARED FOLDER"
Write-Host "  Select 'Reguverse Assistant (Test)' and click Add"
Write-Host ""
Write-Host "  If SHARED FOLDER is empty, add manually:"
Write-Host "  File > Options > Trust Center > Settings >"
Write-Host "  Trusted Add-in Catalogs > Add: $SharePath"
Write-Host "============================================"
Write-Host ""
Read-Host "Press Enter to exit"
