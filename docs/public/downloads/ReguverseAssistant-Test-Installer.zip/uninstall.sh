#!/bin/bash
# Reguverse Assistant Uninstaller (Test (International)) - macOS

ADDIN_DIR="$HOME/Library/Containers/com.microsoft.Word/Data/Documents/wef"

echo "Uninstalling Reguverse Assistant (Test)..."
rm -f "$ADDIN_DIR/manifest-test.xml"

# Clear Office cache
CACHE_DIR="$HOME/Library/Containers/com.microsoft.Word/Data/Library/Caches"
if [ -d "$CACHE_DIR" ]; then
    echo "Clearing Office cache..."
    find "$CACHE_DIR" -name "*.manifest" -delete 2>/dev/null || true
fi

echo ""
echo "Uninstall complete. Close ALL Word windows and re-open."
