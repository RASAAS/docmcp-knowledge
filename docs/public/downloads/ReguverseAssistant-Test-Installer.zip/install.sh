#!/bin/bash
# Reguverse Assistant Installer (Test (International)) - macOS

set -e

echo "============================================"
echo " Reguverse Assistant - Test (International)"
echo " 国际测试版"
echo " (app-test.team-ra.org)"
echo "============================================"
echo ""

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
MANIFEST_SRC="$SCRIPT_DIR/manifest.xml"
ADDIN_DIR="$HOME/Library/Containers/com.microsoft.Word/Data/Documents/wef"

echo "[1/3] Creating add-in directory..."
mkdir -p "$ADDIN_DIR"

echo "[2/3] Copying manifest file..."
cp "$MANIFEST_SRC" "$ADDIN_DIR/manifest-test.xml"

echo "[3/3] Verifying..."
if [ -f "$ADDIN_DIR/manifest-test.xml" ]; then
    echo ""
    echo "============================================"
    echo " Installation complete!"
    echo ""
    echo " IMPORTANT: Close ALL Word windows first,"
    echo " then re-open Word."
    echo ""
    echo " To activate:"
    echo " 1. Open Word"
    echo " 2. Insert > My Add-ins"
    echo " 3. Select 'Reguverse Assistant (Test)'"
    echo "============================================"
else
    echo "[ERROR] Installation failed."
    exit 1
fi
