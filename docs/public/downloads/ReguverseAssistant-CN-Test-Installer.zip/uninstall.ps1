# Reguverse Assistant Uninstaller (CN Test)
$ErrorActionPreference = "SilentlyContinue"

Write-Host "Uninstalling Reguverse Assistant CN (Test)..." -ForegroundColor Yellow

$CatalogDir = Join-Path $env:LOCALAPPDATA "Microsoft\Office\16.0\Wef\ReguverseCNTest"
$RegPath = "HKCU:\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\reguverse-cn-test"
$CachePath = Join-Path $env:LOCALAPPDATA "Microsoft\Office\16.0\Wef\webextensions"

Write-Host "[1/3] Removing manifest and catalog..."
if (Test-Path $CatalogDir) { Remove-Item -Path $CatalogDir -Recurse -Force }

Write-Host "[2/3] Removing registry entry..."
if (Test-Path $RegPath) { Remove-Item -Path $RegPath -Recurse -Force }

Write-Host "[3/3] Clearing Office Add-in cache..."
if (Test-Path $CachePath) { Remove-Item -Path $CachePath -Recurse -Force }

Write-Host ""
Write-Host "Uninstall complete. Close ALL Word windows and re-open." -ForegroundColor Green
Write-Host "Press Enter to exit..." -ForegroundColor Gray
Read-Host
