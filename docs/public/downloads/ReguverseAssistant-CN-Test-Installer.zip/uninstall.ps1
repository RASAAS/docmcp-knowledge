$ErrorActionPreference = "SilentlyContinue"
Write-Host "============================================"
Write-Host "  Uninstalling: Reguverse Assistant CN (Test)"
Write-Host "============================================"
Write-Host ""

$CatalogDir = "$env:LOCALAPPDATA\Microsoft\Office\16.0\Wef\ReguverseCNTest"
$RegPath = "HKCU:\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\reguverse-cn-test"
$CacheDir = "$env:LOCALAPPDATA\Microsoft\Office\16.0\Wef\webextensions"

Write-Host "[1/5] Removing manifest and catalog directory..."
if (Test-Path $CatalogDir) { Remove-Item -Recurse -Force $CatalogDir }

Write-Host "[2/5] Removing catalog registry entry..."
if (Test-Path $RegPath) { Remove-Item -Force $RegPath }

Write-Host "[3/5] Removing old Developer sideload entries (if any)..."
Remove-Item -Force -ErrorAction SilentlyContinue "HKCU:\SOFTWARE\Microsoft\Office\16.0\WEF\Developer"
Remove-Item -Force -ErrorAction SilentlyContinue "HKCU:\SOFTWARE\Microsoft\Office\16.0\Wef\Developer"
$oldDir = "$env:LOCALAPPDATA\ReguverseAddins"
if (Test-Path $oldDir) { Remove-Item -Recurse -Force $oldDir }

Write-Host "[4/5] Clearing Office Add-in cache..."
if (Test-Path $CacheDir) { Remove-Item -Recurse -Force $CacheDir }

Write-Host "[5/5] Clearing WebView2 cache..."
Get-ChildItem "$env:LOCALAPPDATA\Packages\Microsoft.Win32WebViewHost_*" -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    $ac = Join-Path $_.FullName "AC"
    if (Test-Path $ac) { Remove-Item -Recurse -Force $ac }
}

Write-Host ""
Write-Host "============================================"
Write-Host "  Uninstall complete."
Write-Host "  Please close ALL Word windows and re-open."
Write-Host "============================================"
Write-Host ""
Read-Host "Press Enter to exit"
