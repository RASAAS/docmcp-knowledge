@echo off
chcp 65001 >nul
title Reguverse Assistant Uninstaller (CN Test)
echo ============================================
echo  Uninstalling: Reguverse Assistant CN (Test)
echo ============================================
echo.

set "CATALOG_DIR=%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\ReguverseCNTest"
set "REG_PATH=HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\reguverse-cn-test"
set "CACHE_DIR=%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\webextensions"

echo [1/3] Removing manifest and catalog...
if exist "%CATALOG_DIR%" rd /s /q "%CATALOG_DIR%" >nul 2>&1

echo [2/3] Removing registry entry...
reg delete "%REG_PATH%" /f >nul 2>&1

echo [3/3] Clearing Office Add-in cache...
if exist "%CACHE_DIR%" rd /s /q "%CACHE_DIR%" >nul 2>&1

echo.
echo ============================================
echo  Uninstall complete.
echo  Please close ALL Word windows and re-open.
echo ============================================
echo.
pause
