@echo off
chcp 65001 >nul
title Reguverse Assistant Installer (CN Test)
echo ============================================
echo  Reguverse Assistant - CN Test
echo  国内测试版
echo  (app-test.reguverse.com)
echo ============================================
echo.

set "CATALOG_DIR=%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\ReguverseCNTest"
set "CATALOG_GUID=A1B2C3D4-E5F6-7890-ABCD-100000000001"
set "CATALOG_KEY=reguverse-cn-test"
set "REG_PATH=HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%CATALOG_KEY%"

echo [1/4] Clearing old Office Add-in cache...
if exist "%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\webextensions" (
    rd /s /q "%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\webextensions" >nul 2>&1
)

echo [2/4] Creating catalog directory...
if not exist "%CATALOG_DIR%" mkdir "%CATALOG_DIR%"

echo [3/4] Copying manifest file...
copy /Y "%~dp0manifest.xml" "%CATALOG_DIR%\manifest.xml" >nul
if errorlevel 1 (
    echo [ERROR] Failed to copy manifest file.
    pause
    exit /b 1
)

echo [4/4] Registering trusted add-in catalog...
reg add "%REG_PATH%" /v Id /t REG_SZ /d "%CATALOG_GUID%" /f >nul 2>&1
reg add "%REG_PATH%" /v Url /t REG_SZ /d "%CATALOG_DIR%" /f >nul 2>&1
reg add "%REG_PATH%" /v Flags /t REG_DWORD /d 1 /f >nul 2>&1

echo.
echo ============================================
echo  Installation complete!
echo.
echo  IMPORTANT: Close ALL Word windows first,
echo  then re-open Word.
echo.
echo  To activate the add-in:
echo  1. Open Microsoft Word
echo  2. Home tab ^> Add-ins (or Insert ^> My Add-ins)
echo  3. Click "SHARED FOLDER" tab
echo  4. Select "Reguverse Assistant CN (Test)"
echo  5. Click "Add"
echo.
echo  If "SHARED FOLDER" tab is empty:
echo  - Make sure ALL Office apps are closed
echo  - Re-run this installer
echo  - Re-open Word
echo ============================================
echo.
pause
